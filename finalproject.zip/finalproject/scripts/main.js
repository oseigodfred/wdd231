// Tech Skills Hub Ghana - Main JavaScript File
// All JavaScript functionality for the website

// Strict mode for better error handling
'use strict';

// DOM Content Loaded Event
document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize all functionality
    initNavigation();
    initCurrentYear();
    initTestimonialSlider();
    initStatCounters();
    initResourceFilters();
    initPositionFilters();
    initPositionToggles();
    initContactForm();
    initNewsletterForm();
    initApplicationForm();
    
});

// ============================================
// Navigation Menu
// ============================================
function initNavigation() {
    const hamburger = document.getElementById('hamburger');
    const nav = document.getElementById('mainNav');
    
    if (hamburger && nav) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            nav.classList.toggle('active');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            const isClickInsideNav = nav.contains(event.target);
            const isClickOnHamburger = hamburger.contains(event.target);
            
            if (!isClickInsideNav && !isClickOnHamburger && nav.classList.contains('active')) {
                hamburger.classList.remove('active');
                nav.classList.remove('active');
            }
        });
        
        // Close menu when pressing Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && nav.classList.contains('active')) {
                hamburger.classList.remove('active');
                nav.classList.remove('active');
            }
        });
        
        // Close menu when clicking on a nav link
        const navLinks = nav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                hamburger.classList.remove('active');
                nav.classList.remove('active');
            });
        });
    }
}

// ============================================
// Update Current Year in Footer
// ============================================
function initCurrentYear() {
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
        const currentYear = new Date().getFullYear();
        yearElement.textContent = currentYear;
    }
}

// ============================================
// Testimonial Slider
// ============================================
function initTestimonialSlider() {
    const track = document.getElementById('testimonialTrack');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (!track || !prevBtn || !nextBtn) return;
    
    const cards = track.querySelectorAll('.testimonial-card');
    let currentIndex = 0;
    const totalCards = cards.length;
    
    function updateSlider() {
        const offset = -currentIndex * 100;
        track.style.transform = `translateX(${offset}%)`;
    }
    
    prevBtn.addEventListener('click', function() {
        currentIndex = (currentIndex - 1 + totalCards) % totalCards;
        updateSlider();
    });
    
    nextBtn.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % totalCards;
        updateSlider();
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowLeft') {
            prevBtn.click();
        } else if (event.key === 'ArrowRight') {
            nextBtn.click();
        }
    });
    
    // Auto-play (optional - can be removed if not desired)
    let autoplayInterval = setInterval(function() {
        nextBtn.click();
    }, 5000);
    
    // Pause autoplay on hover
    track.addEventListener('mouseenter', function() {
        clearInterval(autoplayInterval);
    });
    
    track.addEventListener('mouseleave', function() {
        autoplayInterval = setInterval(function() {
            nextBtn.click();
        }, 5000);
    });
}

// ============================================
// Animated Statistics Counters
// ============================================
function initStatCounters() {
    const statCards = document.querySelectorAll('.stat-number');
    
    if (statCards.length === 0) return;
    
    const animateCounter = function(element) {
        const target = parseInt(element.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const increment = target / (duration / 16); // 60 FPS
        let current = 0;
        
        const updateCounter = function() {
            current += increment;
            if (current < target) {
                element.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target;
            }
        };
        
        updateCounter();
    };
    
    // Intersection Observer for triggering animation when in view
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    statCards.forEach(card => {
        observer.observe(card);
    });
}

// ============================================
// Resource Category Filters
// ============================================
function initResourceFilters() {
    const filterButtons = document.querySelectorAll('.category-filter .filter-btn');
    const resourceCards = document.querySelectorAll('.resource-card');
    
    if (filterButtons.length === 0 || resourceCards.length === 0) return;
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter cards
            resourceCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                
                if (category === 'all' || cardCategory === category) {
                    card.style.display = 'block';
                    // Fade in animation
                    card.style.opacity = '0';
                    setTimeout(() => {
                        card.style.transition = 'opacity 0.3s ease-in-out';
                        card.style.opacity = '1';
                    }, 10);
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ============================================
// Position Department Filters
// ============================================
function initPositionFilters() {
    const filterButtons = document.querySelectorAll('.position-filters .filter-btn');
    const positionCards = document.querySelectorAll('.position-card');
    
    if (filterButtons.length === 0 || positionCards.length === 0) return;
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const department = this.getAttribute('data-department');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter cards
            positionCards.forEach(card => {
                const cardDepartment = card.getAttribute('data-department');
                
                if (department === 'all' || cardDepartment === department) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ============================================
// Position Details Toggle
// ============================================
function initPositionToggles() {
    const toggleButtons = document.querySelectorAll('.toggle-details');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const positionCard = this.closest('.position-card');
            const details = positionCard.querySelector('.position-details');
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            if (isExpanded) {
                details.classList.add('hidden');
                this.setAttribute('aria-expanded', 'false');
                this.textContent = 'View Details';
            } else {
                details.classList.remove('hidden');
                this.setAttribute('aria-expanded', 'true');
                this.textContent = 'Hide Details';
            }
        });
    });
}

// ============================================
// Form Validation Helper Functions
// ============================================
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    // Basic phone validation - adjust regex as needed for Ghana phone numbers
    const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
    return phoneRegex.test(phone);
}

function showError(inputId, errorId, message) {
    const input = document.getElementById(inputId);
    const errorElement = document.getElementById(errorId);
    
    if (input && errorElement) {
        input.classList.add('error');
        errorElement.textContent = message;
    }
}

function clearError(inputId, errorId) {
    const input = document.getElementById(inputId);
    const errorElement = document.getElementById(errorId);
    
    if (input && errorElement) {
        input.classList.remove('error');
        errorElement.textContent = '';
    }
}

function clearAllFormErrors(formId) {
    const form = document.getElementById(formId);
    if (form) {
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.classList.remove('error');
        });
        
        const errorMessages = form.querySelectorAll('.error-message');
        errorMessages.forEach(error => {
            error.textContent = '';
        });
    }
}

// ============================================
// Contact Form Validation and Submission
// ============================================
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, select, textarea');
    
    // Real-time validation on blur
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateContactField(this.id);
        });
    });
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Clear previous errors
        clearAllFormErrors('contactForm');
        
        // Validate all fields
        let isValid = true;
        
        if (!validateContactField('firstName')) isValid = false;
        if (!validateContactField('lastName')) isValid = false;
        if (!validateContactField('email')) isValid = false;
        if (!validateContactField('phone')) isValid = false;
        if (!validateContactField('program')) isValid = false;
        
        if (isValid) {
            // Simulate form submission
            submitContactForm();
        }
    });
}

function validateContactField(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return true;
    
    const value = field.value.trim();
    const errorId = fieldId + 'Error';
    let isValid = true;
    
    switch(fieldId) {
        case 'firstName':
        case 'lastName':
            if (value === '') {
                showError(fieldId, errorId, 'This field is required');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'email':
            if (value === '') {
                showError(fieldId, errorId, 'Email is required');
                isValid = false;
            } else if (!validateEmail(value)) {
                showError(fieldId, errorId, 'Please enter a valid email address');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'phone':
            if (value === '') {
                showError(fieldId, errorId, 'Phone number is required');
                isValid = false;
            } else if (!validatePhone(value)) {
                showError(fieldId, errorId, 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'program':
            if (value === '') {
                showError(fieldId, errorId, 'Please select a program');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
    }
    
    return isValid;
}

function submitContactForm() {
    const form = document.getElementById('contactForm');
    const successMessage = document.getElementById('formSuccess');
    
    // Simulate API call with timeout
    setTimeout(function() {
        form.reset();
        form.style.display = 'none';
        successMessage.classList.remove('hidden');
        
        // Scroll to success message
        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Optional: Reset form after 5 seconds
        setTimeout(function() {
            form.style.display = 'block';
            successMessage.classList.add('hidden');
        }, 5000);
    }, 500);
}

// ============================================
// Newsletter Form Validation and Submission
// ============================================
function initNewsletterForm() {
    const form = document.getElementById('newsletterForm');
    if (!form) return;
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const emailInput = document.getElementById('newsletterEmail');
        const errorElement = document.getElementById('newsletterError');
        const successMessage = document.getElementById('newsletterSuccess');
        const email = emailInput.value.trim();
        
        // Clear previous errors
        errorElement.textContent = '';
        emailInput.classList.remove('error');
        
        // Validate email
        if (email === '') {
            emailInput.classList.add('error');
            errorElement.textContent = 'Email is required';
            return;
        }
        
        if (!validateEmail(email)) {
            emailInput.classList.add('error');
            errorElement.textContent = 'Please enter a valid email address';
            return;
        }
        
        // Simulate submission
        setTimeout(function() {
            form.reset();
            form.style.display = 'none';
            successMessage.classList.remove('hidden');
            
            // Reset after 5 seconds
            setTimeout(function() {
                form.style.display = 'block';
                successMessage.classList.add('hidden');
            }, 5000);
        }, 500);
    });
}

// ============================================
// Application Form Validation and Submission
// ============================================
function initApplicationForm() {
    const form = document.getElementById('applicationForm');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, select, textarea');
    
    // Real-time validation on blur
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateApplicationField(this.id);
        });
    });
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Clear previous errors
        clearAllFormErrors('applicationForm');
        
        // Validate all required fields
        let isValid = true;
        
        if (!validateApplicationField('appFirstName')) isValid = false;
        if (!validateApplicationField('appLastName')) isValid = false;
        if (!validateApplicationField('appEmail')) isValid = false;
        if (!validateApplicationField('appPhone')) isValid = false;
        if (!validateApplicationField('position')) isValid = false;
        if (!validateApplicationField('coverLetter')) isValid = false;
        if (!validateApplicationField('resume')) isValid = false;
        
        if (isValid) {
            submitApplicationForm();
        }
    });
}

function validateApplicationField(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return true;
    
    const value = field.value.trim();
    const errorId = fieldId + 'Error';
    let isValid = true;
    
    switch(fieldId) {
        case 'appFirstName':
        case 'appLastName':
            if (value === '') {
                showError(fieldId, errorId, 'This field is required');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'appEmail':
            if (value === '') {
                showError(fieldId, errorId, 'Email is required');
                isValid = false;
            } else if (!validateEmail(value)) {
                showError(fieldId, errorId, 'Please enter a valid email address');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'appPhone':
            if (value === '') {
                showError(fieldId, errorId, 'Phone number is required');
                isValid = false;
            } else if (!validatePhone(value)) {
                showError(fieldId, errorId, 'Please enter a valid phone number');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'position':
            if (value === '') {
                showError(fieldId, errorId, 'Please select a position');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'coverLetter':
            if (value === '') {
                showError(fieldId, errorId, 'Cover letter is required');
                isValid = false;
            } else if (value.length < 50) {
                showError(fieldId, errorId, 'Please provide a more detailed cover letter (minimum 50 characters)');
                isValid = false;
            } else {
                clearError(fieldId, errorId);
            }
            break;
            
        case 'resume':
            if (field.files.length === 0) {
                showError(fieldId, errorId, 'Please upload your resume');
                isValid = false;
            } else {
                const file = field.files[0];
                const maxSize = 5 * 1024 * 1024; // 5MB
                const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                
                if (file.size > maxSize) {
                    showError(fieldId, errorId, 'File size must be less than 5MB');
                    isValid = false;
                } else if (!allowedTypes.includes(file.type)) {
                    showError(fieldId, errorId, 'Only PDF, DOC, and DOCX files are allowed');
                    isValid = false;
                } else {
                    clearError(fieldId, errorId);
                }
            }
            break;
    }
    
    return isValid;
}

function submitApplicationForm() {
    const form = document.getElementById('applicationForm');
    const successMessage = document.getElementById('applicationSuccess');
    
    // Simulate API call with timeout
    setTimeout(function() {
        form.reset();
        form.style.display = 'none';
        successMessage.classList.remove('hidden');
        
        // Scroll to success message
        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Optional: Reset form after 7 seconds
        setTimeout(function() {
            form.style.display = 'block';
            successMessage.classList.add('hidden');
        }, 7000);
    }, 500);
}

// ============================================
// Smooth Scrolling for Anchor Links
// ============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(event) {
        const href = this.getAttribute('href');
        
        // Skip if href is just "#"
        if (href === '#') {
            event.preventDefault();
            return;
        }
        
        const targetElement = document.querySelector(href);
        
        if (targetElement) {
            event.preventDefault();
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ============================================
// Accessibility: Skip to Main Content
// ============================================
// Add skip link functionality if needed
const skipLink = document.querySelector('a[href="#main"]');
if (skipLink) {
    skipLink.addEventListener('click', function(event) {
        event.preventDefault();
        const main = document.querySelector('main');
        if (main) {
            main.setAttribute('tabindex', '-1');
            main.focus();
            main.scrollIntoView({ behavior: 'smooth' });
        }
    });
}
